import { useEffect, useRef } from "react";
import "reveal.js/reveal.css";
import "reveal.js/theme/white.css";
import "./PreviewModal.css";
import {
  initRevealDeck,
  buildTextElementStyle,
  buildMediaElementStyle,
  buildSlideContainerStyle,
  buildColorThemeStyle,
  getTextContent,
  getVisibleSlidesForPreview,
  getSlideTextElements,
  getSlideMediaElements,
  getSlideDimensions,
  getSlideTransition,
  buildAnimationMap,
  getFragmentProps,
} from "../core/render/revealRenderer";

export default function PreviewModal({ slides, presentation, onClose }) {
  const deckRef = useRef(null);
  const { width, height } = getSlideDimensions(presentation);
  const colorThemeStyle = buildColorThemeStyle(presentation);

  useEffect(() => {
    if (!deckRef.current) return;
    const deck = initRevealDeck(deckRef.current, width, height);
    return () => {
      deck.destroy();
    };
  }, [slides, width, height]);

  const visibleSlides = getVisibleSlidesForPreview(slides);

  return (
    <div className="preview-overlay" style={colorThemeStyle}>
      <div
        className="preview-window"
        style={{
          width: `${width}px`,
          height: `${height}px`,
          maxWidth: "95vw",
          maxHeight: "95vh",
        }}
      >
        <button className="preview-close" onClick={onClose}>
          Close
        </button>

        <div className="reveal" ref={deckRef}>
          <div className="slides">
            {visibleSlides.map((slide, slideIndex) => {
              const textElements = getSlideTextElements(slide);
              const mediaElements = getSlideMediaElements(slide);
              const animationMap = buildAnimationMap(slide);

              return (
                <section
                  key={`slide-${slideIndex}`}
                  data-transition={getSlideTransition(slide)}
                  style={{ background: slide.contents?.background ?? "white" }}
                >
                  <div style={buildSlideContainerStyle(width, height)}>

                    {textElements.map((textElement, index) => {
                      const fragmentProps = getFragmentProps(animationMap.get(textElement.id));
                      return (
                        <div
                          key={textElement.id || index}
                          style={buildTextElementStyle(textElement, index)}
                          {...fragmentProps}
                        >
                          {getTextContent(textElement)}
                        </div>
                      );
                    })}

                    {mediaElements.map((media, index) => {
                      const fragmentProps = getFragmentProps(animationMap.get(media.id));
                      return (
                        <img
                          key={media.id || index}
                          src={media["file-link"]}
                          alt=""
                          style={buildMediaElementStyle(media, index)}
                          {...fragmentProps}
                        />
                      );
                    })}

                  </div>
                </section>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}