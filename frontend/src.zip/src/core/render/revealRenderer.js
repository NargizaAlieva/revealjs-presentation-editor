import Reveal from "reveal.js";
import { getSlideSize, getTextElements, getMediaElements } from "../../utils/slidesetRenderUtils";

export function buildTextElementStyle(textElement, index) {
  const formatting = textElement.paragraphs?.[0]?.formatting ?? {};
  const rotation = textElement.rotation ?? 0;

  return {
    position: "absolute",
    left: `${textElement.position?.x ?? 0}px`,
    top: `${textElement.position?.y ?? 0}px`,
    width: `${textElement.width ?? 300}px`,
    height: `${textElement.height ?? 80}px`,
    background: textElement.background ?? "transparent",
    overflow: "hidden",
    zIndex: textElement["z-index"] ?? index + 1,
    ...(rotation ? { transform: `rotate(${rotation}deg)` } : {}),
    fontSize: formatting.size ?? (index === 0 ? "44px" : "28px"),
    fontWeight: formatting.weight ?? (index === 0 ? "bold" : "normal"),
    fontStyle: formatting.italics ? "italic" : "normal",
    color: formatting.color ?? "var(--text-dark, black)",
    textAlign: formatting.align ?? "left",
    lineHeight: formatting["line-spacing"] ?? "1.4",
    boxSizing: "border-box",
  };
}

export function buildMediaElementStyle(media, index) {
  const rotation = media.rotation ?? 0;

  return {
    position: "absolute",
    left: `${media.position?.x ?? 0}px`,
    top: `${media.position?.y ?? 0}px`,
    width: `${media.width ?? 200}px`,
    height: `${media.height ?? 120}px`,
    objectFit: "contain",
    zIndex: media["z-index"] ?? index + 1,
    ...(rotation ? { transform: `rotate(${rotation}deg)` } : {}),
  };
}

export function buildSlideContainerStyle(width, height) {
  return {
    position: "relative",
    width: `${width}px`,
    height: `${height}px`,
    overflow: "hidden",
  };
}

export function getTextContent(textElement) {
  return (
    textElement?.paragraphs
      ?.map((paragraph) =>
        paragraph?.runs?.map((run) => run?.text || "").join("")
      )
      .join("\n") || ""
  );
}

export function getSlideDimensions(presentation) {
  return getSlideSize(presentation);
}

export function getVisibleSlidesForPreview(slides) {
  return (slides || []).filter((slide) => !slide.hidden);
}

export function getSlideTextElements(slide) {
  return getTextElements(slide);
}

export function getSlideMediaElements(slide) {
  return getMediaElements(slide);
}

export function initRevealDeck(containerElement, width, height) {
  const deck = new Reveal(containerElement, {
    controls: true,
    progress: true,
    center: false,
    hash: false,
    embedded: true,
    width,
    height,
    margin: 0,
    minScale: 0.5,
    maxScale: 2.0,
  });

  deck.initialize().then(() => {
    deck.layout();
    deck.sync();
  });

  return deck;
}

export function buildColorThemeStyle(presentation) {
  const colorTheme = presentation?.slideset?.master?.["color-theme"] ?? [];
  const cssVars = {};
  colorTheme.forEach((entry) => {
    cssVars[`--${entry["css-variable-name"]}`] = entry.color;
  });
  return cssVars;
}

export function getSlideTransition(slide, defaultTransition = "slide") {
  const transition = slide?.contents?.transition;
  const validTransitions = ["fade", "slide", "convex", "concave", "zoom", "none"];
  if (transition && validTransitions.includes(transition)) {
    return transition;
  }
  return defaultTransition;
}

const FRAGMENT_EFFECT_CLASSES = new Set([
  "grow",
  "shrink",
  "shrink-down",
  "fade-out",
  "fade-up",
  "fade-down",
  "fade-left",
  "fade-right",
  "fade-in-then-out",
  "fade-in-then-semi-out",
  "highlight-red",
  "highlight-green",
  "highlight-blue",
  "highlight-current-red",
  "highlight-current-green",
  "highlight-current-blue",
  "strike",
]);

const SPEED_MAP = {
  0.5: "fast",
  1: undefined,
  2: "slow",
};

export function buildAnimationMap(slide) {
  const animations = slide?.contents?.animations ?? [];
  const map = new Map();
  animations.forEach((animation) => {
    if (animation?.id) map.set(animation.id, animation);
  });
  return map;
}

export function getFragmentProps(animation) {
  if (!animation) return null;

  const effect = animation.effect ?? "fade-in";
  const sequence = animation.sequence;
  const rawSpeed = animation["effect-options"]?.speed ?? animation.speed;
  const speed = SPEED_MAP[rawSpeed];

  const classes = ["fragment"];
  if (effect !== "fade-in" && effect !== "none" && FRAGMENT_EFFECT_CLASSES.has(effect)) {
    classes.push(effect);
  }

  return {
    className: classes.join(" "),
    "data-fragment-index": Number.isFinite(sequence) ? sequence : undefined,
    "data-fragment-speed": speed,
  };
}